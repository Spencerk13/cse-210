class TerminalService:
    
    
    def __init__(self):
        self._guess = ''

    def set_guess(self, guess):
        self._guess = guess

    
