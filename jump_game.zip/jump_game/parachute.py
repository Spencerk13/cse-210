class Parachute:
    
    def __init__(self):
        self._chute = '___'

    